﻿
namespace RawData;

public class Tyres
{
    public Tyres(int age, double pressure)
    {
        Age = age;
        Pressure = pressure;
    }

    public int Age { get; set; }
    public double Pressure { get; set; }
}
