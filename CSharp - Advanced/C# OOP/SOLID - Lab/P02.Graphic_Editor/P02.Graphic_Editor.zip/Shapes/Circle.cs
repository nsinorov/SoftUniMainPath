﻿using P02.Graphic_Editor.Interfaces;

namespace P02.Graphic_Editor.Shapes
{
    public class Circle : IShape
    {
        public string Draw() => "I'm Circle";
    }
}
