﻿using P02.Graphic_Editor.Interfaces;

namespace P02.Graphic_Editor.Shapes
{
    public class Rectangle : IShape
    {
        public string Draw() => "I'm Rectangle";
    }
}
