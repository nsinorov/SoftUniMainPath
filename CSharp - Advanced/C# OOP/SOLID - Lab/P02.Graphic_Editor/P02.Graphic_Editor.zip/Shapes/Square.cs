﻿using P02.Graphic_Editor.Interfaces;

namespace P02.Graphic_Editor.Shapes
{
    public class Square : IShape
    {
        public string Draw() => "I'm Square";
    }
}
