﻿using ExplicitInterfaces.Core.Interfaces;
using ExplicitInterfaces.Core;

IEngine engine = new Engine();
engine.Run();
