﻿using CollectionHierarchy.Core.Interfaces;
using CollectionHierarchy.Core;

IEngine engine = new Engine();
engine.Run();
