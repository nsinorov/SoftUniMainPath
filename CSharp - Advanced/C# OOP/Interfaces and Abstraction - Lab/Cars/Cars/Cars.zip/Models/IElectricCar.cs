﻿namespace Cars.Models;

interface IElectricCar : ICar
{
    public int Baterry { get; }
}
