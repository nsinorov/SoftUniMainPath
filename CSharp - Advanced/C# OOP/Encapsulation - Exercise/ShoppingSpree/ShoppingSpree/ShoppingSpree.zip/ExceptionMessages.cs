﻿namespace ShoppingSpree
{
    public class ExceptionMessages
    {
        public const string NameExceptionMessage = "Name cannot be empty";
        public const string MoneyExeptionMessage = "Money cannot be negative";
    }
}