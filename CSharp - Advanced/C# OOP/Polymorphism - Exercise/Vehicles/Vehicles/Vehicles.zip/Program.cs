﻿using Vehicles.Core.Interfaces;
using Vehicles.Core;

IEngine engine = new Engine();
engine.Run();