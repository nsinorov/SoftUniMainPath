﻿

namespace WildFarm.Models.Interfaces;

public interface IFeline
{
    public string Breed { get; }
}
