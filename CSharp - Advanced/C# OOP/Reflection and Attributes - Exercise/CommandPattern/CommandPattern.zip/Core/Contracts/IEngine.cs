﻿namespace CommandPattern.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}