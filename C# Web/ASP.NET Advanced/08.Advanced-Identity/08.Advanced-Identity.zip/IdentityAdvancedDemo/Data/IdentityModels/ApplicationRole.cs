﻿using Microsoft.AspNetCore.Identity;

namespace IdentityAdvancedDemo.Data.IdentityModels
{
    public class ApplicationRole : IdentityRole<Guid>
    {
    }
}
