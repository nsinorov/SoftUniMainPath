﻿namespace CreditsAppWithDb.Data
{
    public class CreditDecision
    {
        public int Id { get; set; }
        public int Score { get; set; }
        public string Decision { get; set; }
    }
}
