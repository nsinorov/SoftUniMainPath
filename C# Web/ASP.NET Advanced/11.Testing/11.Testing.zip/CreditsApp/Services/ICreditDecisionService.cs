﻿namespace CreditsApp.Services
{
    public interface ICreditDecisionService
    {
        string GetDecision(int creditScore);
    }
}
