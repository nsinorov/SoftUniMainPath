﻿namespace PetStore.Data.Models.Enums
{
    public enum DeliveryType
    {
        OnSite = 0,
        CourierExpress = 1,
        PostExpress = 2,
    }
}
