﻿// ReSharper disable InconsistentNaming
namespace PetStore.Data.Models.Common
{
    public static class ProductValidationConstants
    {
        public const int NameMaxLength = 70;
    }
}
