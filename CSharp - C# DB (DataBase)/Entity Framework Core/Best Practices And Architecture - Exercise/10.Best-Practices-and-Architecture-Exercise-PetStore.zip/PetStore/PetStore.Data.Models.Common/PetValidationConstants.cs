﻿// ReSharper disable InconsistentNaming
namespace PetStore.Data.Models.Common
{
    public static class PetValidationConstants
    {
        public const int NameMaxLength = 50;
    }
}