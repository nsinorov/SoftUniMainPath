﻿namespace PetStore.Data.Models.Common
{
    public static class ClientValidationConstants
    {
        public const int NameMaxLength = 50;
    }
}
