﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-140PNU1\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}