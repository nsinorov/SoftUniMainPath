﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-140PNU1\SQLEXPRESS;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
