﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-140PNU1\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
