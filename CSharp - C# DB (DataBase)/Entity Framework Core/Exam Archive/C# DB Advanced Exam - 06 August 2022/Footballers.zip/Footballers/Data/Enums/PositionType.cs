﻿namespace Footballers.Data.Enums;

public enum PositionType
{
    Goalkeeper = 0,
    Defender = 1,
    Midfielder = 2,
    Forward = 3
}