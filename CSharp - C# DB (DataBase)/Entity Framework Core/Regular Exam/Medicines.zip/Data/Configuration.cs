﻿namespace Medicines.Data
{
    public class Configuration
    {
        //DB CONFIG TO DATA BASE
        public static string ConnectionString = @"Server=.;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
