﻿namespace ProductShop.DTOs.Import;

public class ImportCategoryAndProduct
{
    public int CategoryId { get; set; }
    public int ProductId { get; set; }
}